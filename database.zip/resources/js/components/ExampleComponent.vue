<template>
    <v-app>
        <v-btn color="primary">
            Primary
        </v-btn>
    </v-app>

</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
