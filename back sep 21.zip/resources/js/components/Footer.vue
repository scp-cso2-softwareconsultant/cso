<template>
    <v-footer color="red" app>
        <span class="white--text">Copyright &copy; CSO2 System 2021</span>
    </v-footer>
</template>

<script>
export default {
}
</script>
