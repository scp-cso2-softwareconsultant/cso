<template>
    <v-col md="3">
        <h1 class="my-4">Shop Name</h1>
        <v-card>
            <v-list dense>
                <v-list-item link href="#">
                    <v-list-item-content>
                        <v-list-item-title>Category 1</v-list-item-title>
                    </v-list-item-content>
                </v-list-item>
                <v-list-item link href="#">
                    <v-list-item-content>
                        <v-list-item-title>Category 2</v-list-item-title>
                    </v-list-item-content>
                </v-list-item>
                <v-list-item link href="#">
                    <v-list-item-content>
                        <v-list-item-title>Category 3</v-list-item-title>
                    </v-list-item-content>
                </v-list-item>
            </v-list>
        </v-card>
    </v-col>
</template>