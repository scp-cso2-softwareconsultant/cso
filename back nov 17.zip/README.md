

## Start Up ( Linux or wsl )

1.) Download node js v14.17.5 and nvm (Node version manager)

    sudo apt-get update
    sudo apt-get install nodejs
    sudo apt-get install npm
    curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.35.3/install.sh | bash
    export NVM_DIR="$([ -z "${XDG_CONFIG_HOME-}" ] && printf %s "${HOME}/.nvm" || printf %s "${XDG_CONFIG_HOME}/nvm")"
    [ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
    nvm install 14.17.5
    nvm use 14.17.5

3.) Download php 7.4.22 , MySql, vue 

    sudo apt update
    sudo apt install apache2
    sudo apt install php libapache2-mod-php
    sudo apt install php-{bcmath,bz2,curl,gd,json,mbstring,mysql,xml,zip}
    sudo apt install mysql-server
    sudo systemctl start mysql
    sudo systemctl restart apache2
    npm install vue


4.) Download composer php package manager

    sudo apt update
    sudo apt install php-cli unzip
    cd ~
    curl -sS https://getcomposer.org/installer -o composer-setup.php

    HASH=`curl -sS https://composer.github.io/installer.sig`
    echo $HASH
    php -r "if (hash_file('SHA384', 'composer-setup.php') === '$HASH') { echo 'Installer verified'; } else { echo 'Installer corrupt'; unlink('composer-setup.php'); } echo PHP_EOL;"
    sudo php composer-setup.php --install-dir=/usr/local/bin --filename=composer
    composer

    apt search mbstring
    sudo apt install php-mbstring
    

5.) Download laravel Installer 4.2.7

    composer global require "laravel/installer"
    
6.) Check if it's working

    nvm --version
    npm --version
    node --version
    php --version
    composer --version
    laravel --version
    
  
--


## Setting up environment 

1.) Clone repository

    git clone https://github.com/Senpai-Coders/cso.git

2.) Cd into the directory 

3.) install composer dependencies

    composer install
    
4.) Install npm dependencies
    
    npm install
5.) Open mysql service and apache2 server 

     sudo service mysql start
     sudo service apache2 restart
    
6.) Create a copy of your .env file
    .env files are not generally committed to source control for security reasons. But there is a .env.example which is a template of the .env file that the project expects us to have. So we will make a copy of the .env.example file and create a .env file that we can start to fill out to do things like database configuration in the next few steps.
  
    cp .env.example .env
    
This will create a copy of the .env.example file in your project and name the copy simply .env.

7.)  Generate an app encryption key
    
    php artisan key:generate
   
8.) Create an empty database for our application
    Create an empty database for your project using the database tools you prefer (My favorite is SequelPro for mac). In our example we created a database called “test”. Just create an empty database here, the exact steps will depend on your system setup.

9.) In the .env file, add database information to allow Laravel to connect to the database
We will want to allow Laravel to connect to the database that you just created in the previous step. To do this, we must add the connection credentials in the .env file and Laravel will handle the connection from there.

In the .env file fill in the DB_HOST, DB_PORT, DB_DATABASE, DB_USERNAME, and DB_PASSWORD options to match the credentials of the database you just created. This will allow us to run migrations and seed the database in the next step.

10.) Migrate the database

    php artisan migrate
    
11.) [Optional]: Seed the database

    php artisan db:seed

12.) Run the backend 
    
    php artisan serve

13.) Open another Terminal for front-end. This will load js files , html files, and css files. Keep in mind that scss errors are normal 

    npm run dev
    
14.) After building run. For vue server to run live 

    npm run watch-poll
    
--

## Add Heroku Repo 

1.) Install Heroku 
   
    sudo snap install --classic heroku 
 
2.) Add remote from heroku 

    heroku git:remote -a cso-deployment
    
3.) Push some changes to heroku
    
4.) Change Key value
    
    heroku config:add APP_KEY=< copy your APP_ENV value from your .env file >
    # if not seen type 
    php artisan key:generate
    
    
--
<p align="center"><a href="https://laravel.com" target="_blank"><img src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg" width="400"></a></p>

<p align="center">
<a href="https://travis-ci.org/laravel/framework"><img src="https://travis-ci.org/laravel/framework.svg" alt="Build Status"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/dt/laravel/framework" alt="Total Downloads"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/v/laravel/framework" alt="Latest Stable Version"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/l/laravel/framework" alt="License"></a>
</p>

## About Laravel

Laravel is a web application framework with expressive, elegant syntax. We believe development must be an enjoyable and creative experience to be truly fulfilling. Laravel takes the pain out of development by easing common tasks used in many web projects, such as:

- [Simple, fast routing engine](https://laravel.com/docs/routing).
- [Powerful dependency injection container](https://laravel.com/docs/container).
- Multiple back-ends for [session](https://laravel.com/docs/session) and [cache](https://laravel.com/docs/cache) storage.
- Expressive, intuitive [database ORM](https://laravel.com/docs/eloquent).
- Database agnostic [schema migrations](https://laravel.com/docs/migrations).
- [Robust background job processing](https://laravel.com/docs/queues).
- [Real-time event broadcasting](https://laravel.com/docs/broadcasting).

Laravel is accessible, powerful, and provides tools required for large, robust applications.

## Learning Laravel

Laravel has the most extensive and thorough [documentation](https://laravel.com/docs) and video tutorial library of all modern web application frameworks, making it a breeze to get started with the framework.

If you don't feel like reading, [Laracasts](https://laracasts.com) can help. Laracasts contains over 1500 video tutorials on a range of topics including Laravel, modern PHP, unit testing, and JavaScript. Boost your skills by digging into our comprehensive video library.

## Laravel Sponsors

We would like to extend our thanks to the following sponsors for funding Laravel development. If you are interested in becoming a sponsor, please visit the Laravel [Patreon page](https://patreon.com/taylorotwell).

### Premium Partners

- **[Vehikl](https://vehikl.com/)**
- **[Tighten Co.](https://tighten.co)**
- **[Kirschbaum Development Group](https://kirschbaumdevelopment.com)**
- **[64 Robots](https://64robots.com)**
- **[Cubet Techno Labs](https://cubettech.com)**
- **[Cyber-Duck](https://cyber-duck.co.uk)**
- **[Many](https://www.many.co.uk)**
- **[Webdock, Fast VPS Hosting](https://www.webdock.io/en)**
- **[DevSquad](https://devsquad.com)**
- **[Curotec](https://www.curotec.com/services/technologies/laravel/)**
- **[OP.GG](https://op.gg)**

## Contributing

Thank you for considering contributing to the Laravel framework! The contribution guide can be found in the [Laravel documentation](https://laravel.com/docs/contributions).

## Code of Conduct

In order to ensure that the Laravel community is welcoming to all, please review and abide by the [Code of Conduct](https://laravel.com/docs/contributions#code-of-conduct).

## Security Vulnerabilities

If you discover a security vulnerability within Laravel, please send an e-mail to Taylor Otwell via [taylor@laravel.com](mailto:taylor@laravel.com). All security vulnerabilities will be promptly addressed.

## License

The Laravel framework is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).
